import React from 'react'

export default function Mainbody() {
  return (
    <div>
      <main>
        <div className='name'>
            <h2>Hello, Shital Patil</h2>
        </div>
      </main>
    </div>
  )
}

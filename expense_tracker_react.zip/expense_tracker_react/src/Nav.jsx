import React from 'react'

export default function Nav() {
  return (
    <div>
      <header>
        <h4>Expense Tracker</h4>
      </header>
    </div>
  )
}
